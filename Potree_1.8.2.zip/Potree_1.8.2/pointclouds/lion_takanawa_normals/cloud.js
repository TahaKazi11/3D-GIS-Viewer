{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "",
    "points": 341989,
    "boundingBox": {
        "lx": -4.985000133514404,
        "ly": 1.0390000343322755,
        "lz": -3.444999933242798,
        "ux": 0.6999998092651367,
        "uy": 6.723999977111816,
        "uz": 2.240000009536743
    },
    "tightBoundingBox": {
        "lx": -4.985000133514404,
        "ly": 1.0390000343322755,
        "lz": -3.444999933242798,
        "ux": -0.7889999747276306,
        "uy": 6.723999977111816,
        "uz": 1.1239999532699586
    },
    "pointAttributes": [
        "POSITION_CARTESIAN",
        "COLOR_PACKED",
        "NORMAL_OCT16"
    ],
    "spacing": 0.04923354461789131,
    "scale": 0.001,
    "hierarchyStepSize": 5
}