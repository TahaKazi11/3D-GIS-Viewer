{
	"version": "1.7",
	"octreeDir": "data",
	"boundingBox": {
		"lx": -0.748212993144989,
		"ly": -2.78040599822998,
		"lz": 2.54782128334045,
		"ux": 3.89967638254166,
		"uy": 1.86748337745667,
		"uz": 7.1957106590271
	},
	"tightBoundingBox": {
		"lx": -0.748212993144989,
		"ly": -2.78040599822998,
		"lz": 2.55100011825562,
		"ux": 2.4497377872467,
		"uy": 1.48934376239777,
		"uz": 7.1957106590271
	},
	"pointAttributes": [
		"POSITION_CARTESIAN",
		"COLOR_PACKED",
		"NORMAL_SPHEREMAPPED"
	],
	"spacing": 0.0750000029802322,
	"scale": 0.001,
	"hierarchyStepSize": 6
}
